#ifndef __test_h__
#define __test_h__

#include <ap_int.h>

void myTopFunc(bool SW0, bool SW1, bool SW2, bool SW6, bool SW7, bool SW12, bool SW13, bool SW14, bool SW15, int entry[4], ap_uint<8> code7seg[4], ap_uint<4> anodes[4]);

#endif
