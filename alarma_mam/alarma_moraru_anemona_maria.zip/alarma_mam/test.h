#ifndef __test_h__
#define __test_h__

#include <ap_int.h>

void myTopFunc(bool SW0, bool SW1, bool SW2, bool SW6, bool SW7, bool C1, bool C2, bool C3, bool C4, int cod[4], ap_uint<8> code7seg[4], ap_uint<4> anodes[4]);

#endif
